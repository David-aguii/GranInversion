 
import './App.css';
import ListaTareas from './ListaTareas';

function App() {
  return (
    <div className="App">
       <h1>Hello Dojo!</h1>
       <h3>Things i need to do:</h3>
       <ListaTareas/>
    </div>
  );
}

export default App;
