import React from 'react';

const ListaTareas = () => {
  return (
        <ul>
            <li>Learn react</li>
            <li>Climb Mt. Everest</li>
            <li>Run a marathon</li>
            <li>Feed the dogs</li>
        </ul>
  );
};

export default ListaTareas;